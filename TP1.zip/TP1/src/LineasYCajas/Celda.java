package LineasYCajas;

public class Celda {

    public char estado;
    /*
    X: Vertice
    C: Caja
    H: Linea Horizontal
    V: Linea Vertical

    A: linea de jugador A
    B: linea de jugador B
     */

    public Celda(char estado) {
        this.estado = estado;
    }


}
